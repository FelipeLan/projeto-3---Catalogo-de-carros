package br.gov.sp.projeto03_paginadedetalhescarros;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Identificadores dos produtos disponíveis para seleção
    private static final int PRODUTO_NISSAN = 1;
    private static final int PRODUTO_MAZDA = 2;
    private static final int PRODUTO_HONDA = 3;

    private ImageView imgDestaque;
    private TextView tvSelecionado;

    // Guarda qual produto está atualmente selecionado
    private int produtoSelecionado = PRODUTO_NISSAN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgDestaque = findViewById(R.id.imgDestaque);
        tvSelecionado = findViewById(R.id.tvSelecionado);

        ImageView imgNissan = findViewById(R.id.imgNissan);
        ImageView imgMazda = findViewById(R.id.imgMazda);
        ImageView imgHonda = findViewById(R.id.imgHonda);
        Button btnDetalhes = findViewById(R.id.btnDetalhes);
        Button btnLimpar = findViewById(R.id.btnLimpar);

        // Miniaturas: ao clicar, atualiza a imagem em destaque e o produto selecionado
        imgNissan.setOnClickListener(v -> selecionarProduto(PRODUTO_NISSAN));
        imgMazda.setOnClickListener(v -> selecionarProduto(PRODUTO_MAZDA));
        imgHonda.setOnClickListener(v -> selecionarProduto(PRODUTO_HONDA));

        // Abre a Activity de detalhes correspondente ao produto selecionado
        btnDetalhes.setOnClickListener(v -> abrirDetalhes());

        // Limpa a seleção e retorna a tela ao estado inicial
        btnLimpar.setOnClickListener(v -> limparSelecao());

        // Estado inicial da tela
        selecionarProduto(PRODUTO_NISSAN);
    }

    private void selecionarProduto(int produto) {
        produtoSelecionado = produto;
        switch (produto) {
            case PRODUTO_MAZDA:
                imgDestaque.setImageResource(R.drawable.mazda_rx7);
                tvSelecionado.setText(R.string.mazda_nome);
                break;
            case PRODUTO_HONDA:
                imgDestaque.setImageResource(R.drawable.honda_civic_type_r);
                tvSelecionado.setText(R.string.honda_nome);
                break;
            case PRODUTO_NISSAN:
            default:
                imgDestaque.setImageResource(R.drawable.nissangtrr34);
                tvSelecionado.setText(R.string.nissan_nome);
                break;
        }
    }

    private void abrirDetalhes() {
        Intent intent;
        switch (produtoSelecionado) {
            case PRODUTO_MAZDA:
                intent = new Intent(this, MazdaDetalheActivity.class);
                break;
            case PRODUTO_HONDA:
                intent = new Intent(this, HondaDetalheActivity.class);
                break;
            case PRODUTO_NISSAN:
            default:
                intent = new Intent(this, NissanDetalheActivity.class);
                break;
        }
        startActivity(intent);
    }

    private void limparSelecao() {
        // Retorna a tela principal ao seu estado inicial (produto padrão: Nissan)
        selecionarProduto(PRODUTO_NISSAN);
    }
}
