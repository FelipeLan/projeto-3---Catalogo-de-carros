package br.gov.sp.projeto03_paginadedetalhescarros;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MazdaDetalheActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mazda_detalhe);

        Button btnVoltar = findViewById(R.id.btnVoltar);
        // Ao clicar em VOLTAR, encerra esta tela e retorna à tela principal
        btnVoltar.setOnClickListener(v -> finish());
    }
}
